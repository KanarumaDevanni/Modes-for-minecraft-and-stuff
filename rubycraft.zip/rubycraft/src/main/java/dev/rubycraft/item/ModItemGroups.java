package dev.rubycraft.item;

import dev.rubycraft.RubyCraft;
import dev.rubycraft.block.ModBlocks;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public final class ModItemGroups {
    public static final ItemGroup RUBYCRAFT_GROUP = Registry.register(
            Registries.ITEM_GROUP,
            new Identifier(RubyCraft.MOD_ID, "main"),
            FabricItemGroup.builder()
                    .displayName(Text.translatable("itemGroup.rubycraft.main"))
                    .icon(() -> new ItemStack(ModItems.RUBY))
                    .entries((context, entries) -> {
                        entries.add(ModItems.RUBY);
                        entries.add(ModItems.HEALING_CHARM);
                        entries.add(ModBlocks.RUBY_ORE);
                        entries.add(ModBlocks.RUBY_BLOCK);
                    })
                    .build());

    private ModItemGroups() {
    }

    public static void register() {
        RubyCraft.LOGGER.info("Registering item groups");
    }
}
