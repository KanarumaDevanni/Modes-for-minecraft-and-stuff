package dev.rubycraft.item;

import dev.rubycraft.RubyCraft;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public final class ModItems {
    public static final Item RUBY = registerItem("ruby", new Item(new FabricItemSettings()));

    public static final Item HEALING_CHARM = registerItem("healing_charm",
            new HealingCharmItem(new FabricItemSettings().maxDamage(16)));

    private ModItems() {
    }

    private static Item registerItem(String name, Item item) {
        return Registry.register(Registries.ITEM, new Identifier(RubyCraft.MOD_ID, name), item);
    }

    public static void register() {
        RubyCraft.LOGGER.info("Registering items");
    }
}
