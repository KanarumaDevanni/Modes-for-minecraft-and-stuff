package dev.rubycraft.item;

import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

public class HealingCharmItem extends Item {
    private static final int COOLDOWN_TICKS = 200; // 10 seconds

    public HealingCharmItem(Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);

        if (!world.isClient) {
            user.heal(6.0f);
            user.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 100, 1));
            stack.damage(1, user, player -> player.sendToolBreakStatus(hand));
        }

        user.getItemCooldownManager().set(this, COOLDOWN_TICKS);
        return TypedActionResult.success(stack, world.isClient());
    }
}
