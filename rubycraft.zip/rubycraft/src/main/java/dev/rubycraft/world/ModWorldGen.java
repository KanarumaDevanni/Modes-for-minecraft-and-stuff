package dev.rubycraft.world;

import dev.rubycraft.RubyCraft;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;
import net.minecraft.world.gen.GenerationStep;
import net.minecraft.world.gen.feature.PlacedFeature;

public final class ModWorldGen {
    public static final RegistryKey<PlacedFeature> RUBY_ORE_PLACED = RegistryKey.of(
            RegistryKeys.PLACED_FEATURE, new Identifier(RubyCraft.MOD_ID, "ruby_ore"));

    private ModWorldGen() {
    }

    public static void register() {
        BiomeModifications.addFeature(
                BiomeSelectors.foundInOverworld(),
                GenerationStep.Feature.UNDERGROUND_ORES,
                RUBY_ORE_PLACED);
    }
}
