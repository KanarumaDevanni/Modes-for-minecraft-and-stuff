package dev.rubycraft.command;

import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.registry.RegistryKey;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.world.World;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class ModCommands {
    private record Home(RegistryKey<World> dimension, double x, double y, double z, float yaw, float pitch) {
    }

    private static final Map<UUID, Home> HOMES = new HashMap<>();

    private ModCommands() {
    }

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(CommandManager.literal("sethome").executes(ModCommands::setHome));
            dispatcher.register(CommandManager.literal("home").executes(ModCommands::goHome));
        });
    }

    private static int setHome(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
        HOMES.put(player.getUuid(), new Home(
                player.getWorld().getRegistryKey(),
                player.getX(), player.getY(), player.getZ(),
                player.getYaw(), player.getPitch()));
        ctx.getSource().sendFeedback(() -> Text.literal("Home set!"), false);
        return 1;
    }

    private static int goHome(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
        Home home = HOMES.get(player.getUuid());

        if (home == null) {
            ctx.getSource().sendError(Text.literal("You have no home yet. Use /sethome first."));
            return 0;
        }

        ServerWorld world = ctx.getSource().getServer().getWorld(home.dimension());
        if (world == null) {
            ctx.getSource().sendError(Text.literal("Your home dimension is not available."));
            return 0;
        }

        player.teleport(world, home.x(), home.y(), home.z(), home.yaw(), home.pitch());
        ctx.getSource().sendFeedback(() -> Text.literal("Welcome home!"), false);
        return 1;
    }
}
