package dev.rubycraft;

import dev.rubycraft.block.ModBlocks;
import dev.rubycraft.command.ModCommands;
import dev.rubycraft.item.ModItemGroups;
import dev.rubycraft.item.ModItems;
import dev.rubycraft.world.ModWorldGen;
import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class RubyCraft implements ModInitializer {
    public static final String MOD_ID = "rubycraft";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        ModBlocks.register();
        ModItems.register();
        ModItemGroups.register();
        ModWorldGen.register();
        ModCommands.register();
        LOGGER.info("RubyCraft loaded!");
    }
}
